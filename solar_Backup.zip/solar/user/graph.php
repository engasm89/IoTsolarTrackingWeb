<!doctype html public "-//w3c//dtd html 3.2//en">
 <?php
    if(isset($_GET["panel"]) )
    {$farm=$_GET["farm"];
        $panel = $_GET["panel"];
    // echo $farm;
    // echo $panel;
    }
?>
<html>
<head>
    <style>
    @media only screen and (max-width: 600px) {
  body {
   zoom: 70%;
  }
}
    
        .card {
  /* Add shadows to create the "card" effect */
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
  transition: 0.3s;
  padding:20px;
border-radius: 5px;
float:center;
width:800px;
}

.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 8px 16px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}
.button5 {
  background-color: white;
  color: black;
  border: 2px solid #555555;
}

.button5:hover {
  background-color: #555555;
  color: white;
}

        </style>
<title>graphview....</title>
</head>
<body >
    <center>
        <div class="card">
            <button class="button button5" onclick="location.href='secondpage.php?solarfarm=<?php echo $farm ?>'" >BACK</button><br>

<?php
include "config.php";


if($stmt = $connection->query("SELECT logtime,current,voltage FROM espdataupload WHERE panel='$panel' ORDER BY ID ASC LIMIT 12")){

//   echo "No of records : ".$stmt->num_rows."<br>";
$php_data_array = Array(); // create PHP array

while ($row = $stmt->fetch_row()) {
//   echo "<tr><td>$row[0]</td><td>$row[1]</td><td>$row[2]</td></tr>";
   $php_data_array[] = $row; // Adding to array
   }

}else{
echo $connection->error;
}
//print_r( $php_data_array);
// You can display the json_encode output here. 
// echo json_encode($php_data_array); 

// Transfor PHP array to JavaScript two dimensional array 
echo "<script>
        var my_2d = ".json_encode($php_data_array)."
</script>";
?>


<div id="curve_chart"></div>
<br><br>


<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">

      // Load the Visualization API and the corechart package.
      google.charts.load('current', {packages: ['corechart']});
      google.charts.setOnLoadCallback(drawChart);
	  
      function drawChart() {

        // Create the data table.
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Month');
        data.addColumn('number', 'current');
		data.addColumn('number', 'voltage');
// 		data.addColumn('number', 'Exp_fixed');
// 		data.addColumn('number', 'Exp_var');
        for(i = 0; i < my_2d.length; i++)
    data.addRow([my_2d[i][0], parseInt(my_2d[i][1]),parseInt(my_2d[i][2])]);
       var options = {
          title: '',
        curveType: 'function',
		width: 800,
        height: 500,
          legend: { position: 'bottom' }
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));
        chart.draw(data, options);
       }
	///////////////////////////////
</script>
</div>
</center>
</body></html>







