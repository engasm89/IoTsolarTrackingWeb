<!DOCTYPE HTML><html>
    <?php
    if(isset($_GET["solarfarm"]) )
    {
        $farm = $_GET["solarfarm"];
   //  echo $farm;
    }
?>
   <head>
     <title>home...</title>
    <meta name="apple-mobile-web-app-capable" content="yes">
<meta content="text/html; charset=UTF-8" http-equiv="content-type">
<meta name="viewport" content="width=device-width, intial-scale=1">
<meta name="viewport" content="width=device-width, initial-scale=1"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel="stylesheet" href="./style.css">
     <style>
@media only screen and (max-width: 600px) {
  body {
   zoom: 65%;
  }
}
            html {font-family: Arial; display: inline-block; text-align: center;}

      body {
     max-width: 900px; margin:0px auto; padding-bottom: 25px;
   }
       .topnav {
     overflow: hidden;
     background-color: #0A1128;
     width: 400px;

   }


     .content {
     padding: 5%;
   }
   h1 {
     font-size: 1.8rem;
     color: white;
   }

   .card-grid {
     max-width: 400px;
     margin: 0 auto;
     display: grid;

     grid-gap: 2rem;
     grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
   }

   .card {
     background-color: white;
   border-radius: 10px;
     box-shadow: 2px 2px 12px 1px rgba(140,140,140,.5);
   }
   .maindiv {
     background-color: white;
     margin-top: 20px;
     border-radius: 40px;
     width: 480px;
     box-shadow: 2px 2px 12px 1px rgba(140,140,140,.5);
   }

   .card-title {
     font-size: 1.2rem;
     font-weight: bold;
     color: #034078
   }
   
                  .button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 8px 16px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}
.button5 {
  background-color: white;
  color: black;
  border: 2px solid #555555;
}

.button5:hover {
  background-color: #555555;
  color: white;
}

     </style>
         <center>
     <div class="maindiv">


   </head>
   <div class="topnav">
     <h1>SOLAR MONITORING SYSTEM</h1>
   </div>
   <?php echo "<br>" ?>
       <button class="button button5" onclick="location.href='sliderindex.php'" >BACK</button><br>
   <?php echo "<br>" ?>

   <body>

		<?php


		include "config.php";
		
			if($stmt = $connection->query("SELECT distinct panelname from assignedpanel where formname='$farm'")){


  	while ($row = mysqli_fetch_array($stmt)){
			     $panel=$row['panelname'];
    //echo $panel;

     $sql = "SELECT  current,voltage from espdataupload where panel='$panel' order by id desc limit 1";
     $result = $connection->query($sql);
      $counter=0;

     if ($result->num_rows > 0) {
$counter++;
       // output data of each row
       while($row = $result->fetch_assoc()) {
        
           $current= $row['current'];
             $voltage= $row['voltage'];
          //   echo "$panel $current $voltage";
         
       if($current==0 && $voltage>0){
                        echo '<a href="index2.php?solarpanel='.$panel.'&& farm='.$farm.'"><td><input type="submit" name="rowButton" value="'.$panel.'" style="width:100px;margin-top:5px;height:70px; border:2px solid black; background-color:orange;"/> </td>';
                         
       }
       else  if($current>0 && $voltage==0){
                        echo '<a href="index2.php?solarpanel='.$panel.'&& farm='.$farm.'"><td><input type="submit" name="rowButton" value="'.$panel.'" style="width:100px;margin-top:5px;height:70px; border:2px solid black; background-color:orange;"/> </td>';
                         
       }
       else if($current>0 || $voltage > 0){
                        echo '<a href="index2.php?solarpanel='.$panel.'&& farm='.$farm.'"><td><input type="submit" name="rowButton" value="'.$panel.'" style="width:100px;height:70px;margin-top:5px; border:2px solid black; background-color:green;"/> </td>';
                        
       }
       else if($current==0 && $voltage == 0){
                        echo '<a href="index2.php?solarpanel='.$panel.'&& farm='.$farm.'"><td><input type="submit" name="rowButton" value="'.$panel.'" style="width:100px;height:70px; margin-top:5px;border:2px solid black; background-color:red;"/> </td>';
       }
       else if($counter==4){
            echo "<br>";
              
            $counter=0;
       }
     
       }

     } else {
       echo "0 results";
     }
		//	}

}}
 echo "<br>";
 echo "<br>";
     ?>
     

    

   </body>
 </div>
 </center>
   </html>
