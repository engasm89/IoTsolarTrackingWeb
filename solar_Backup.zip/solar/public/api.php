<?php
include 'config.php';

 //$con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
    //read the json file contents
 $data = file_get_contents('php://input');

$jsonobj = $data;
$obj = json_decode($jsonobj);

$panel=$obj->panel;
$current=$obj->current;
$voltage=$obj->voltage;


 $Sql_Query = "insert into espdataupload (panel,current,voltage,logtime) values ('$panel','$current','$voltage',CURRENT_TIMESTAMP())";

 if(mysqli_query($connection,$Sql_Query)){

 echo 'Data Inserted Successfully';
 
 }
 else{

 echo ' Data not inserted ';

 }
 mysqli_close($connection);

   



?>
