<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel="stylesheet" href="./style.css">

</head>

<body>

<!-- partial:index.partial.html -->
<?php
include "config.php";

$sql = "SELECT current, voltage,logtime FROM sensordata  ORDER BY ID DESC LIMIT 1 ";
$result = $con->query($sql);

if ($result->num_rows > 0) {

  // output data of each row
  while($row = $result->fetch_assoc()) {
    $current= $row["current"];
    $voltage= $row["voltage"];
    $logtime=$row["logtime"];
    // echo "meterId:- " . $row["meterId"]. "  reading:- " . $row["reading"]. " logtime:- " . $row["logTime"]. "<br><br>";

  }

} else {
  echo "0 results";
}



?>


<div id="cards">

<figure class="card card--normal">
  <div class="card__image-container">
    <img src="image/sun.png" alt="Eevee" class="card__image">
  </div>

  <figcaption class="card__caption">
    <h1 class="card__name">CURRENT</h1>

    <h3 class="card__type">Current

    </h3>

    <table class="card__stats">
      <tbody><tr>
        <th>CURRENT</th>
        <td><?php echo $current ?></td>
      </tr>
      <!-- <tr>
        <th>Attack</th>
        <td>55</td>
      </tr>

      <tr>
        <th>Defense</th>
        <td>50</td>
      </tr>

      <tr>
        <th>Special Attack</th>
        <td>45</td>
      </tr>
      <tr>
        <th>Special Defense</th>
        <td>65</td>
      </tr>
      <tr>
        <th>Speed</th>
        <td>55</td>
      </tr> -->
    </tbody></table>

    <div class="card__abilities">
      <h4 class="card__ability">
        <span class="card__label">Last Updated at</span>
        <?php echo $logtime ?>
      </h4>
      <h4 class="card__ability">
        <span class="card__label">Detail</span>
        <a href="graph.php?data=dht1humidity">Graph</a>
      </h4>
    </div>
  </figcaption>
</figure>

<!--<figure class="card card--water">-->
<!--  <div class="card__image-container">-->
<!--    <img src="image/voltage.png" alt="Vaporeon" class="card__image">-->
<!--  </div>-->

<!--  <figcaption class="card__caption">-->
<!--    <h1 class="card__name">VOLTAGE</h1>-->

<!--    <h3 class="card__type">-->
<!--      Voltage-->
<!--    </h3>-->

<!--    <table class="card__stats">-->
<!--      <tbody><tr>-->
<!--        <th>Voltage</th>-->
<!--        <td><?php echo $voltage; ?></td>-->
<!--      </tr>-->
<!--      <tr>-->
<!--      </tbody></table>-->

<!--      <div class="card__abilities">-->
<!--        <h4 class="card__ability">-->
<!--          <span class="card__label">Last Updated at</span>-->
<!--          <?php echo $logtime ?>-->
<!--        </h4>-->
<!--        <h4 class="card__ability">-->
<!--          <span class="card__label">Detail</span>-->
<!--          <a href="graph.php?data=dht1temp">Graph</a>-->
<!--        </h4>-->
<!--      </div>-->
<!--    </figcaption>-->
<!--  </figure>-->



<figure class="card card--electric">
  <div class="card__image-container">
    <img src="image/voltage.png" alt="Jolteon" class="card__image">
  </div>

  <figcaption class="card__caption">
    <h1 class="card__name">VOLTAGE</h1>

    <h3 class="card__type">
      VOLTAGE
    </h3>

    <table class="card__stats">
      <tbody><tr>
        <th>VOLTAGE</th>
        <td><?php echo $voltage; ?></td>
      </tr>
    </tbody></table>

    <div class="card__abilities">
      <h4 class="card__ability">
        <span class="card__label">Last Updated at</span>
        <?php echo $logtime ?>
      </h4>
      <h4 class="card__ability">
        <span class="card__label">Detail</span>
        <a href="graph.php?data=dht2humidity">Graph</a>
      </h4>
    </div>
  </figcaption>
</figure>

<!--<figure class="card card--fire">-->
<!--  <div class="card__image-container">-->
<!--    <img src="image/dht11.png" alt="Flareon" class="card__image">-->
<!--  </div>-->

<!--  <figcaption class="card__caption">-->
<!--    <h1 class="card__name">TEMPERATURE</h1>-->

<!--    <h3 class="card__type">-->
<!--      Inside-->
<!--    </h3>-->

<!--    <table class="card__stats">-->
<!--      <tbody><tr>-->
<!--        <th>Temperature</th>-->
<!--        <td><?php echo $dht2temp; ?></td>-->
<!--      </tr>-->


<!--    </tbody></table>-->

<!--    <div class="card__abilities">-->
<!--      <h4 class="card__ability">-->
<!--        <span class="card__label">Last Updated at</span>-->
<!--        <?php echo $logtime ?>-->
<!--      </h4>-->
<!--      <h4 class="card__ability">-->
<!--        <span class="card__label">Detail</span>-->
<!--        <a href="graph.php?data=dht2temp">Graph</a>-->
<!--      </h4>-->
<!--    </div>-->
<!--  </figcaption>-->
<!--</figure>-->

<!--<figure class="card card--psychic">-->
<!--  <div class="card__image-container">-->
<!--    <img src="image/soil.png" alt="Espeon" class="card__image">-->
<!--  </div>-->

<!--  <figcaption class="card__caption">-->
<!--    <h1 class="card__name">SOIL MOISTURE</h1>-->

<!--    <h3 class="card__type">-->
<!--      OUTSIDE-->
<!--    </h3>-->

<!--    <table class="card__stats">-->
<!--      <tbody><tr>-->
<!--        <th>SOIL MOISTURE</th>-->
<!--        <td><?PHP echo $soilm1 ?></td>-->
<!--      </tr>-->
<!--    </tbody></table>-->

<!--    <div class="card__abilities">-->
<!--      <h4 class="card__ability">-->
<!--        <span class="card__label">Last Updated at</span>-->
<!--        <?php echo $logtime ?>-->
<!--      </h4>-->
<!--      <h4 class="card__ability">-->
<!--        <span class="card__label">Detail</span>-->
<!--        <a href="graph.php?data=soilm1">Graph</a>-->
<!--      </h4>-->
<!--    </div>-->
<!--  </figcaption>-->
<!--</figure>-->

<!--<figure class="card card--dark">-->
<!--  <div class="card__image-container">-->
<!--    <img src="image/soil.png" alt="Umbreon" class="card__image">-->
<!--  </div>-->

<!--  <figcaption class="card__caption">-->
<!--    <h1 class="card__name">SOIL MOISTURE</h1>-->

<!--    <h3 class="card__type">-->
<!--      INSIDE-->
<!--    </h3>-->

<!--    <table class="card__stats">-->
<!--      <tbody><tr>-->
<!--        <th>SOIL MOISTURE</th>-->
<!--        <td><?PHP echo $soilm2 ?></td>-->
<!--      </tr>-->
<!--    </tbody></table>-->

<!--    <div class="card__abilities">-->
<!--      <h4 class="card__ability">-->
<!--        <span class="card__label">Last Updated at</span>-->
<!--        <?php echo $logtime ?>-->
<!--      </h4>-->
<!--      <h4 class="card__ability">-->
<!--        <span class="card__label">Detail</span>-->
<!--        <a href="graph.php?data=soilm2">Graph</a>-->
<!--      </h4>-->
<!--    </div>-->
<!--  </figcaption>-->
<!--</figure>-->

<!-- <figure class="card card--grass">
  <div class="card__image-container">
    <img src="https://cdn.bulbagarden.net/upload/thumb/f/f5/470Leafeon.png/600px-470Leafeon.png" alt="Leafeon" class="card__image">
  </div>

  <figcaption class="card__caption">
    <h1 class="card__name">Leafeon</h1>

    <h3 class="card__type">
      grass
    </h3>

    <table class="card__stats">
      <tbody><tr>
        <th>HP</th>
        <td>65</td>
      </tr>
      <tr>
        <th>Attack</th>
        <td>110</td>
      </tr>

      <tr>
        <th>Defense</th>
        <td>130</td>
      </tr>

      <tr>
        <th>Special Attack</th>
        <td>60</td>
      </tr>
      <tr>
        <th>Special Defense</th>
        <td>65</td>
      </tr>
      <tr>
        <th>Speed</th>
        <td>95</td>
      </tr>
    </tbody></table>

    <div class="card__abilities">
      <h4 class="card__ability">
        <span class="card__label">Ability</span>
        Leaf Guard
      </h4>
      <h4 class="card__ability">
        <span class="card__label">Hidden Ability</span>
        Chlorophyll
      </h4>
    </div>
  </figcaption>
</figure>

<figure class="card card--ice">
  <div class="card__image-container">
    <img src="https://cdn.bulbagarden.net/upload/thumb/2/23/471Glaceon.png/600px-471Glaceon.png" alt="Glaceon" class="card__image">
  </div>

  <figcaption class="card__caption">
    <h1 class="card__name">Glaceon</h1>

    <h3 class="card__type">
      ice
    </h3>

    <table class="card__stats">
      <tbody><tr>
        <th>HP</th>
        <td>65</td>
      </tr>
      <tr>
        <th>Attack</th>
        <td>60</td>
      </tr>

      <tr>
        <th>Defense</th>
        <td>110</td>
      </tr>

      <tr>
        <th>Special Attack</th>
        <td>130</td>
      </tr>
      <tr>
        <th>Special Defense</th>
        <td>95</td>
      </tr>
      <tr>
        <th>Speed</th>
        <td>65</td>
      </tr>
    </tbody></table>

    <div class="card__abilities">
      <h4 class="card__ability">
        <span class="card__label">Ability</span>
        Snow Cloak
      </h4>
      <h4 class="card__ability">
        <span class="card__label">Hidden Ability</span>
        Ice Body
      </h4>
    </div>
  </figcaption>
</figure>

<figure class="card card--fairy">
  <div class="card__image-container">
    <img src="https://cdn.bulbagarden.net/upload/thumb/e/e8/700Sylveon.png/600px-700Sylveon.png" alt="Sylveon" class="card__image">
  </div>

  <figcaption class="card__caption">
    <h1 class="card__name">Sylveon</h1>

    <h3 class="card__type">
      fairy
    </h3>

    <table class="card__stats">
      <tbody><tr>
        <th>HP</th>
        <td>95</td>
      </tr>
      <tr>
        <th>Attack</th>
        <td>65</td>
      </tr>

      <tr>
        <th>Defense</th>
        <td>65</td>
      </tr>

      <tr>
        <th>Special Attack</th>
        <td>110</td>
      </tr>
      <tr>
        <th>Special Defense</th>
        <td>130</td>
      </tr>
      <tr>
        <th>Speed</th>
        <td>60</td>
      </tr>
    </tbody></table>

    <div class="card__abilities">
      <h4 class="card__ability">
        <span class="card__label">Ability</span>
        Cute Charm
      </h4>
      <h4 class="card__ability">
        <span class="card__label">Hidden Ability</span>
        Pixilate
      </h4>
    </div>
  </figcaption>
</figure>
</div>


<script id="card-template" type="text/x-handlebars-template">
<figure class="card card--{{type}}">
  <div class="card__image-container">
    <img src="{{imageAddress}}" alt="{{name}}" class="card__image">
  </div>

  <figcaption class="card__caption">
    <h1 class="card__name">{{name}}</h1>

    <h3 class="card__type">e
      {{type}}
    </h3>

    <table class="card__stats">
      <tr>
        <th>HP</th>
        <td>{{hp}}</td>
      </tr>
      <tr>
        <th>Attack</th>
        <td>{{attack}}</td>
      </tr>

      <tr>
        <th>Defense</th>
        <td>{{defense}}</td>
      </tr>

      <tr>
        <th>Special Attack</th>
        <td>{{spAttack}}</td>
      </tr>
      <tr>
        <th>Special Defense</th>
        <td>{{spDefense}}</td>
      </tr>
      <tr>
        <th>Speed</th>
        <td>{{speed}}</td>
      </tr>
    </table>

    <div class="card__abilities">
      <h4 class="card__ability">
        <span class="card__label">Ability</span>
        {{ability1}}
      </h4>
      <h4 class="card__ability">
        <span class="card__label">Hidden Ability</span>
        {{ability2}}
      </h4>
    </div>
  </figcaption>
</figure> -->
</script>
<!-- partial -->
  <script src='https://cdnjs.cloudflare.com/ajax/libs/handlebars.js/4.0.11/handlebars.min.js'></script><script  src="./script.js"></script>

</body>

</html>
