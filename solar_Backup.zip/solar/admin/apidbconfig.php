<?php

//Define your host here.
$HostName = "localhost";

//Define your database username here.

$HostUser = "solar_admin";

//Define your database password here.

$HostPass = "!Colibri2022";

//Define your database name here.
$DatabaseName = "Solar_db-35303137225a";


?>