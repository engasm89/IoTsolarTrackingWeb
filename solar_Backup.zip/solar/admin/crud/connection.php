<?php
$con=mysqli_connect("sdb-58.hosting.stackcp.net","solar_admin","#Client00998","Solar_db-35303137225a");
if(!$con) { die(" Connection Error "); }
?>
